#ifndef OPTION_H_
#define OPTION_H_

void option(int *b,int * a,SDL_Surface * screen,int *screen_w,int *screen_h);



#endif  //  #include  "option.h"
